import React from 'react';
import { createRoot } from 'react-dom/client';

import './index.css';

const root = createRoot(document.querySelector('#root'));

root.render(
  <React.StrictMode>
    <h1>Angela Han</h1>
    <p id="email">
      <a href="mailto:hanangel@usc.edu">hanangel@usc.edu</a>
    </p>

    <p className="fav">
      Favorite Color: <span> Cornflower Blue </span>
    </p>

    <p className="fav">
      Favorite Website:{' '}
      <a href="https://littlealchemy.com/" target="_blank">
        Little Alchemy
      </a>
    </p>

    <img
      className="center"
      src="https://i.pinimg.com/564x/9f/f4/d3/9ff4d36cb80c5c7d5f5550aed4c32791.jpg"
      alt="baking"
    />

    <p className="fav">Course List</p>
    <ul>
      <li>HBIO250: The Pharmacology of Performance-Enhancing Drugs</li>
      <li>HBIO441: Prevention of Athletic Injuries</li>
      <li className="example-class">ITP301: Front-End Web Development</li>
      <li>HBIO202: Nutrition for Life</li>
      <li>DSCI250: Introduction to Data Science</li>
    </ul>
  </React.StrictMode>
);
