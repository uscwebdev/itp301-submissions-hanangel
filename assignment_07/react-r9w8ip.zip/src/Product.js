import React from 'react';
import { useState } from 'react';

export default function Product(prop) {
  const [count, setCount] = useState(0);

  function handleMinusClick() {
    console.log(count);
    if (count > 0) {
      setCount(count - 1);
      console.log(count);
    }
  }

  function handlePlusClick() {
    console.log(count);
    setCount(count + 1);
    console.log(count);
  }

  return (
    <div className="item">
      <div className="container">
        <img src={prop.src} alt={prop.alt + ' plush'} />
        <p>{prop.alt}</p>
        <p>${prop.price}</p>
      </div>
      <div className="itemQuantity">
        <button className="countButton" onClick={handleMinusClick}>
          -
        </button>
        <p>{count}</p>
        <button className="countButton" onClick={handlePlusClick}>
          +
        </button>
      </div>
    </div>
  );
}
