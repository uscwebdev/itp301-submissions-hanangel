import React from 'react';
import { createRoot } from 'react-dom/client';
import './index.css';
import Products from './Products.js';

const root = createRoot(document.querySelector('#root'));

root.render(
  <React.StrictMode>
    <div id="header">
      <h1>your shopping cart</h1>
    </div>

    <Products />

    <div id="footer">
      <h3>© 2023 sumikko gurashi toy shop</h3>
    </div>
  </React.StrictMode>
);
