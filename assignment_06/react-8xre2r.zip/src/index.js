import React from 'react';
import { createRoot } from 'react-dom/client';
import './index.css';
import Product from './Product.js';

const root = createRoot(document.querySelector('#root'));

root.render(
  <React.StrictMode>
    <div id="header">
      <h1>your shopping cart</h1>
    </div>

    <div id="items">
      <div id="row1">
        <Product
          src="https://i.pinimg.com/564x/85/39/20/8539209752052af91dc559d3ac8d2c39.jpg"
          alt="cat with heart"
          price="20"
        />

        <Product
          src="https://i.pinimg.com/564x/65/1e/76/651e7624b27af0f93bb5ab34662ba78f.jpg"
          alt="star"
          price="11"
        />

        <Product
          src="https://i.pinimg.com/564x/ec/02/ac/ec02ac6a04c323416ae3c2ac616afdc0.jpg"
          alt="peach"
          price="12"
        />

        <div className="clearfloat"></div>
      </div>
      <div id="row2">
        <Product
          src="https://i.pinimg.com/564x/38/67/75/386775945754acc7dd939ed7ca607327.jpg"
          alt="pink ice cream"
          price="15"
        />

        <Product
          src="https://i.pinimg.com/564x/a5/6f/23/a56f239711dfc50d4ebf39c81a157415.jpg"
          alt="sunflower plush"
          price="10"
        />

        <Product
          src="https://i.pinimg.com/564x/2c/89/2a/2c892a30e2df015ed5a2a196ef878499.jpg"
          alt="cat burglar"
          price="18"
        />
        <div className="clearfloat"></div>
      </div>
    </div>

    <div id="footer">
      <h3>© 2023 sumikko gurashi toy shop</h3>
    </div>
  </React.StrictMode>
);
