import React from 'react';

export default function Product(prop) {
  return (
    <div className="container">
      <img src={prop.src} alt={prop.alt + ' plush'} />
      <p>{prop.alt}</p>
      <p>${prop.price}</p>
    </div>
  );
}
