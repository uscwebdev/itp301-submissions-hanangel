import React from 'react';

export default function Comment(prop) {
  return (
    <div className="comment">
      <img className="pfp" src={prop.src}/>
      <h4>{prop.name}</h4>
      <h5>{prop.date}</h5>
      <p>{prop.text}</p>
    </div>
  );
}
