import React from 'react';
import { useState } from 'react';

export default function Images() {
  const [src, setSrc] = useState(
    'https://uscwebdev.github.io/itp301-submissions-hanangel/lab_04/img/bakery1.jpeg'
  );

  const [alt, setAlt] = useState('picture of taiyaki');
  const [caption, setCaption] = useState('taiyaki');

  function handleImageChange(newSrc, newAlt, newCap) {
    setSrc(newSrc);
    setAlt(newAlt);
    setCaption(newCap);
  }

  return (
    <div id="gallery">
      <div id="row1">
        <button
          className="imgbutton"
          onClick={() => {
            handleImageChange(
              'https://uscwebdev.github.io/itp301-submissions-hanangel/lab_04/img/bakery1.jpeg',
              'picture of taiyaki',
              'taiyaki'
            );
          }}
        >
          Image 1
        </button>
        <button
          className="imgbutton"
          onClick={() => {
            handleImageChange(
              'https://uscwebdev.github.io/itp301-submissions-hanangel/lab_04/img/bakery2.jpeg',
              'picture of bun w cream',
              'bun with cream filling'
            );
          }}
        >
          Image 2
        </button>
        <button
          className="imgbutton"
          onClick={() => {
            handleImageChange(
              'https://uscwebdev.github.io/itp301-submissions-hanangel/lab_04/img/bakery3.jpeg',
              'picture of pastel heart cake',
              'pastel heart-shaped cake'
            );
          }}
        >
          Image 3
        </button>
        <button
          className="imgbutton"
          onClick={() => {
            handleImageChange(
              'https://uscwebdev.github.io/itp301-submissions-hanangel/lab_04/img/bakery4.jpeg',
              'picture of strawberry cream cake',
              'strawberry cream cake'
            );
          }}
        >
          Image 4
        </button>
        <button
          className="imgbutton"
          onClick={() => {
            handleImageChange(
              'https://uscwebdev.github.io/itp301-submissions-hanangel/lab_04/img/bakery5.jpeg',
              'picture of cloud macarons',
              'cloud-shaped macarons'
            );
          }}
        >
          Image 5
        </button>
        <div className="clearfloat"></div>
      </div>
      <div id="row2"></div>
      <div id="magnify">
        <div className="container">
          <img
            src={src}
            alt={alt}
            caption={caption}
            onClick={() => {
              handleImageChange(src, alt, caption);
            }}
          />
        </div>
      </div>
      <div id="text">
        <h2>{caption}</h2>
      </div>
    </div>
  );
}
