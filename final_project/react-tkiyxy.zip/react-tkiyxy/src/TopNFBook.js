import React from 'react';
import { useState, useEffect } from 'react';
import $ from 'jquery';

const TopNFBook = () => {
  const [topBook, setTopBook] = useState(null);

  useEffect(() => {
    const url =
      'https://api.nytimes.com/svc/books/v3/lists/full-overview.json?api-key=T9tBsBwjfcEeLMZwTxouI0WMkgM07MZX';

    $.ajax({
      url: url,
      method: 'GET',
      dataType: 'json',
      success: function (response) {
        // Assuming the top book is the first book in the first list
        const firstList = response.results.lists[1];
        const topRankedBook = firstList.books[0];
        setTopBook(topRankedBook);
        console.log(topRankedBook);
        console.log('hello');
      },
      error: function (error) {
        console.error('Error fetching data:', error);
      },
    });
  }, []);

  return (
    <div>
      <div id="row2col1">
        {topBook ? (
          <>
            <img
              src={topBook.book_image}
              alt={topBook.title + ' cover image'}
            />
            <div id="NFcaption">
              <h4>{topBook.title}</h4>
              <p>Author: {topBook.author}</p>
              <p>Rank This Week: {topBook.rank}</p>
              <p>{topBook.description}</p>
              <a href={topBook.amazon_product_url} target="_blank">
                Learn more on Amazon
              </a>
            </div>
          </>
        ) : (
          <p>Loading...</p>
        )}
      </div>
      <div id="row2col2">
        <h1>Discover This Week's Top Nonfiction</h1>
      </div>
    </div>
  );
};

export default TopNFBook;
