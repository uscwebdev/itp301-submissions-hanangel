import React from 'react';

function NavBar() {
  return (
    <div className="nav">
      <nav>
        <ul>
          <li>
            <a href="/">Home</a>
          </li>
          <li>
            <a href="/journal">Journal</a>
          </li>
        </ul>
      </nav>
    </div>
  );
}

export default NavBar;
