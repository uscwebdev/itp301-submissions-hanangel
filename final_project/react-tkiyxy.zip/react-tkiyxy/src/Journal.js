import React from 'react';
import { useState } from 'react';
import NavBar from './NavBar.js';
import $ from 'jquery';

export default function Journal() {

  const [searchTerm, setSearchTerm] = useState('');
  const [searchTotal, setSearchTotal] = useState(0);
  const [results, setResults] = useState([]);

  function handleFormSubmission(e) {
    e.preventDefault();

    $.ajax({
      url:
        'https://api.themoviedb.org/3/search/movie?api_key=727e8b05e0ad3943a6356459dddc5e96&query=' +
        searchTerm,
      dataType: 'json',
      success: function (data) {
        console.log(data);
        //console.log(data.results);
        setSearchTotal(data.total_results);
        setResults(data.results);
      },
      error: function (error) {
        console.log(error);
      },
    });
    console.log('hello');
  }

  return (
    <div>
      <header>
        <h1>BOOKWORMS</h1>
        <NavBar></NavBar>
      </header>
      <p>JOURNALLLLLLL</p>

      <div className="row">
        <form
          className="col-12"
          id="search-form"
          onSubmit={handleFormSubmission}
        >
          <div className="form-row">
            <div className="col-12 mt-4 col-sm-6 col-md-4 col-lg-3">
              <label htmlFor="search-term" className="sr-only">
                Search:
              </label>

              <input
                type="text"
                id="search-term"
                className="form-control"
                placeholder="Search..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.currentTarget.value)}
              />
            </div>
            <div className="col-12 mt-4 col-sm-auto">
              <button type="submit" className="btn btn-primary btn-block">
                Search
              </button>
            </div>
          </div>
        </form>
      </div>

      <div className="row">
        <div className="col-12 mt-4 mb-4">
          Showing{' '}
          <span id="num-results" className="font-weight-bold">
            {results.length}
          </span>{' '}
          of{' '}
          <span id="num-total" className="font-weight-bold">
            {searchTotal}
          </span>{' '}
          result(s).
        </div>
      </div>

      <div id="movie-container" className="row">
        {results.map((elt) => {
          console.log(elt);

          return (
            <div className="text-center my-3 col-6 col-sm-4 col-md-3 col-lg-2">
              <img
                alt={elt.title + 'Poster'}
                src={'https://image.tmdb.org/t/p/w500' + elt.poster_path}
              />
              <h5>{elt.title}</h5>
              <div>{elt.release_date}</div>
            </div>
          );
        })}
        </div>
    </div>
  );
}
