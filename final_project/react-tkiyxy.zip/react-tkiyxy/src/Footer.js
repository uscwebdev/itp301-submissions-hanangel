import React from 'react';

function Footer() {
  return (
    <div className="footer">
      <p>BOOKWORMS 2022&copy;</p>
      <p>created with the NYT Books API</p>
    </div>
  );
}

export default Footer;
