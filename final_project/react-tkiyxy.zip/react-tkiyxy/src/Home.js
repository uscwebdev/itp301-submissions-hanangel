import React from 'react';
import { useState, useEffect } from 'react';
import NavBar from './NavBar.js';
import Footer from './Footer.js';
import TopNFBook from './TopNFBook.js';
import $ from 'jquery';

const BooksComponent = () => {
  const [books, setBooks] = useState([]);

  useEffect(() => {
    const url =
      'https://api.nytimes.com/svc/books/v3/lists/current/hardcover-fiction.json?api-key=T9tBsBwjfcEeLMZwTxouI0WMkgM07MZX';

    $.ajax({
      url: url,
      method: 'GET',
      dataType: 'json',
      success: function (response) {
        setBooks(response.results.books); // Update state with the fetched books
      },
      error: function (error) {
        console.error('Error fetching data:', error);
      },
    });
  }, []);

  const topNineBooks = books.slice(0, 9);

  return (
    <div>
      <header>
        <h1>BOOKWORMS</h1>
        <NavBar></NavBar>
      </header>
      <div id="row1">
        <div id="row1col1">
          <h1>Top Hardcover Fiction</h1>
          <h1>Top Hardcover Fiction</h1>
          <h1>Top Hardcover Fiction</h1>
          <h1>Top Hardcover Fiction</h1>
          <h1>Top Hardcover Fiction</h1>
          <h1>Top Hardcover Fiction</h1>
          <h1>Top Hardcover Fiction</h1>
          <h1>Top Hardcover Fiction</h1>
          <h1>Top Hardcover Fiction</h1>
          <h1>Top Hardcover Fiction</h1>
          <h1>Top Hardcover Fiction</h1>
          <h1>Top Hardcover Fiction</h1>
          <h1>Top Hardcover Fiction</h1>
          <h1>Top Hardcover Fiction</h1>
          <h1>Top Hardcover Fiction</h1>
          <h1>Top Hardcover Fiction</h1>
          <h1>Top Hardcover Fiction</h1>
          <h1>Top Hardcover Fiction</h1>
        </div>
        <div id="row1col2">
          <div className="grid-container">
            {topNineBooks.map((book, index) => (
              <div className="grid-item" key={index}>
                <img src={book.book_image} alt={book.title + ' cover image'} />
                <p>
                  {book.title} by {book.author}
                </p>
              </div>
            ))}
          </div>
        </div>
        <div className="clearfloat"></div>
      </div>
      <div id="row2">
        <TopNFBook></TopNFBook>
        <div className="clearfloat"></div>
      </div>
    </div>
  );
};

export default BooksComponent;
