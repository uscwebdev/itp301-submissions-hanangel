import React from 'react';
import { createRoot } from 'react-dom/client';
import './index.css';
import NavBar from './NavBar.js';
import Home from './Home.js';
import Journal from './Journal.js';

import { createBrowserRouter, RouterProvider } from 'react-router-dom';

const router = createBrowserRouter([
  {
    path: '/',
    element: <Home />,
  },
  {
    path: 'journal',
    element: <Journal />,
  },
]);

const root = createRoot(document.querySelector('#root'));

root.render(
  <React.StrictMode>
    <RouterProvider router={router} />
  </React.StrictMode>
);
